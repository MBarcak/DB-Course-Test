from django.shortcuts import render,redirect
from .models import Flight
from .models import Airline
from django.db import connection
from . import models
from .forms import UserForm
from .forms import *
import hashlib
import django.db.models
from django.shortcuts import HttpResponse
import json
import datetime

# Create your views here.

def dictfetchall(cursor):
    result = []
    rows = cursor.fetchall()
    for row in rows:
        dic=dict(zip(['F_ID','dep_date','dep','dest'],[row[0],str(row[1]),row[2],row[3]]))
        result.append(dic)    
    return result

def query(request):
    #flights=Flight.objects.all()
    if request.method == "GET":
        dep = request.GET.get("dep",None)
        dest = request.GET.get("dest",None)
        dep_date = request.GET.get("dep_date",None)
        if dep_date == 'all':
            sql="select * from query_flight1 where dep=\'"+dep+"' and dest=\'"+dest+"\'"
            cursor=connection.cursor()
            cursor.execute(sql)
            rows = dictfetchall(cursor)
            return render(request,'query.html',{"rows":rows})
        else:
            sql="select * from query_flight1 where dep=\'"+dep+"' and dest=\'"+dest+"' and dep_date=\'"+str(dep_date)+"\'"
            cursor=connection.cursor()
            cursor.execute(sql)
            rows = dictfetchall(cursor)
            print(rows)
        return render(request,'query.html',{"rows":rows})
    
def index(request):
    return render(request,'index.html')
    
def get_query(request):
    return render(request,'base.html')
'''
def login(request):
    if request.session.get('is_login',None): #检查session,不允许重复登陆
        return redirect('/index')
    if request.method == "POST":
        login_form = UserForm(request.POST)
        message = "请检查填写的内容！"
        if login_form.is_valid():
            username = login_form.cleaned_data['username']
            password = login_form.cleaned_data['password']
            print(username)
            print(password)
            try:
                sql="select pd,PName from upload where tele=\'"+username+"\'"
                cursor=connection.cursor()
                cursor.execute(sql)
                rows = cursor.fetchall()
                print(rows)
                if rows[0][0] == hashlib.sha1(bytes(password, encoding="utf8")).hexdigest():
                    request.session['is_login'] = True
                    request.session['user_id'] = username
                    request.session['user_name'] = rows[0][1]
                    return render(request,'index.html')
                else:
                    message = "用户名或密码不正确！"
            except:
                message = "用户名或密码不正确！"
        return render(request, 'login/login.html', locals())
    login_form = UserForm()
    return render(request, 'login/login.html',locals())
'''
def login(request):
    if request.session.get('is_login',None): #检查session,不允许重复登陆
        return redirect('/index')
    if request.method == "POST":
        username=request.POST.get('username',None)
        password=request.POST.get('password',None)
        print(username)
        print(password)
        if (password is '') or (username is ''):
            message = "用户名或密码不可为空！"
            return render(request, 'login/login.html',locals())
        try:
            sql="select pd,PName from upload where tele=\'"+username+"\'"
            cursor=connection.cursor()
            cursor.execute(sql)
            rows = cursor.fetchall()
            print(rows)
            print(hashlib.sha1(bytes(password, encoding="utf8")).hexdigest())
            if rows[0][0] == hashlib.sha1(bytes(password, encoding="utf8")).hexdigest():
                sql="select ID_Num from passenger where tele=\'"+username+"\'"
                print(sql)
                cursor=connection.cursor()
                cursor.execute(sql)
                idnum=cursor.fetchone()[0]
                print(idnum)
                request.session['is_login'] = True
                request.session['user_id'] = idnum
                request.session['user_name'] = rows[0][1]
                return render(request,'index.html')
            else:
                message = "用户名或密码不正确！"
        except:
            message = "用户名或密码不正确！"
        return render(request, 'login/login.html', locals())
    return render(request, 'login/login.html',locals())
'''
def register(request):
    if request.session.get('is_login', None): #登陆时不允许注册
        return redirect("/index/")
    if request.method == "POST":
        register_form = RegisterForm(request.POST)
        message = "请检查填写的内容！"
        if register_form.is_valid():  # 获取数据
            username = register_form.cleaned_data['id_num']
            print(type(username))
            password1 = register_form.cleaned_data['password1']
            print(type(password1))
            password2 = register_form.cleaned_data['password2']
            print(type(password2))
            name = register_form.cleaned_data['name']
            print(type(name))
            age = int(register_form.cleaned_data['age'])
            print(type(age))
            tele = register_form.cleaned_data['tele']
            print(type(tele))
            sex = register_form.cleaned_data['sex']
            print(type(sex))
            if sex=='male':
                sex='男'
            else:
                sex='女'
            if password1 != password2:  # 判断两次密码是否相同
                message = "两次输入的密码不同！"
                return render(request, 'login/register.html', locals())
            else:
                sql="select id_num from passenger where id_num=\'"+username+"\'"
                cursor=connection.cursor()
                cursor.execute(sql)
                same_name_user = cursor.fetchall()
                print(same_name_user)
                if same_name_user:  # 身份证唯一
                    message = '用户已经存在！'
                    return render(request, 'login/register.html', locals())
                sql="select tele from passenger where tele=\'"+tele+"\'"
                cursor=connection.cursor()
                cursor.execute(sql)
                same_tele_user = cursor.fetchall()
                if same_tele_user:  
                    message = '该手机号已被注册！'
                    return render(request, 'login/register.html', locals())

                # 当一切都OK的情况下，创建新用户
                #insert into passenger(ID_Num,PName,age,sex,tele,pd) value('110108199902120213','Li Hua',20,'M','13588887777','123456'),
                password0=hashlib.md5(bytes(password1, encoding="utf8")).hexdigest()
                sql="insert into passenger(ID_Num,PName,age,sex,tele,pd) value(\'"+username+"\',\'"+name+"\',"+str(age)+",\'"+sex+"\',\'"+tele+"\',\'"+password0+"\')"
                cursor=connection.cursor()
                cursor.execute(sql)
                return redirect('/login/')  # 自动跳转到登录页面
    return render(request, 'login/register.html', locals())
'''
def register(request):
    if request.session.get('is_login', None): #登陆时不允许注册
        return redirect("/index/")
    if request.method == "POST":
        username = request.POST.get('id_num',None)
        print(username)
        password1 = request.POST.get('password1',None)
        print(password1)
        password2 = request.POST.get('password2',None)
        print(password2)
        name = request.POST.get('name',None)
        print(name)
        age = int(request.POST.get('age',None))
        print(age)
        tele = request.POST.get('tele',None)
        print(tele)
        sex = request.POST.get('password1',None)
        print(type(sex))
        
        if sex=='male':
            sex='男'
        else:
            sex='女'
        if password1 != password2:  # 判断两次密码是否相同
            message = "两次输入的密码不同！"
            return render(request, 'login/register.html', locals())
        else:
            sql="select id_num from passenger where id_num=\'"+username+"\'"
            cursor=connection.cursor()
            cursor.execute(sql)
            same_name_user = cursor.fetchall()
            print(same_name_user)
            if same_name_user:  # 身份证唯一
                message = '用户已经存在！'
                return render(request, 'login/register.html', locals())
            sql="select tele from passenger where tele=\'"+tele+"\'"
            cursor=connection.cursor()
            cursor.execute(sql)
            same_tele_user = cursor.fetchall()
            if same_tele_user:  
                message = '该手机号已被注册！'
                return render(request, 'login/register.html', locals())

            # 当一切都OK的情况下，创建新用户
            #insert into passenger(ID_Num,PName,age,sex,tele,pd) value('110108199902120213','Li Hua',20,'M','13588887777','123456'),
            password0=hashlib.sha1(bytes(password1, encoding="utf8")).hexdigest()
            sql="insert into passenger(ID_Num,PName,age,sex,tele,pd) value(\'"+username+"\',\'"+name+"\',"+str(age)+",\'"+sex+"\',\'"+tele+"\',\'"+password0+"\')"
            cursor=connection.cursor()
            cursor.execute(sql)
            return redirect('/login/')  # 自动跳转到登录页面
    return render(request, 'login/register.html', locals())

def logout(request):
    if not request.session.get('is_login',None):
        return redirect("/index")
    request.session.flush()
    return redirect('/index/')

def queryfetchall(cursor):
    result = []
    rows = cursor.fetchall()
    for row in rows:
        dic=dict(zip(['F_ID','dep_date','dep','dest','dep_time','dest_time','price1','price2','price3','seat1','seat2','seat3','company','p_type'],[row[0],str(row[1]),str(row[2]),str(row[3]),str(row[4]),str(row[5]),str(row[6]),str(row[7]),str(row[8]),str(row[9]),str(row[10]),str(row[11]),row[12],row[13]]))
        result.append(dic)
    print(result)
    return result

def query_flight(request):
    if request.method == "GET":
        F_ID = request.GET.get("F_ID",None)
        dep_date = request.GET.get("dep_date",None)
        sql="select * from query_flight2 where F_ID=\'"+F_ID+"' and dep_date=\'"+str(dep_date)+"\'"
        cursor=connection.cursor()
        cursor.execute(sql)
        rows=queryfetchall(cursor)
        dep=rows[0]['dep']
        dest=rows[0]['dest']
        #插入查询记录
        sql="select count(*) from query_table"
        cursor=connection.cursor()
        cursor.execute(sql)
        num=cursor.fetchone()
        query_num=int(num[0])+1
        print(dep)
        ID_Num=request.session['user_id']
        F_ID_l=F_ID
        dep_date_l=dep_date
        dep_l=dep
        dest_l=dest
        query_date=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(query_date)
        cursor=connection.cursor()
        cursor.execute("insert query_table(query_num,ID_Num,F_ID,F_ID_l,dep_date,dep_date_l,query_date,dep_l,dest_l) value(%s,%s,%s,%s,%s,%s,%s,%s,%s)",(query_num,ID_Num,F_ID,F_ID_l,dep_date,dep_date_l,query_date,dep_l,dest_l))
    return render(request,'query_flight.html',{"rows":rows})
    
def select(request):
    return render(request,'select.html')
    
def his_fetchall(cursor):
    result = []
    rows = cursor.fetchall()
    for row in rows:
        dic=dict(zip(['query_date','F_ID_l','dep_date_l','dep_l','dest_l'],[str(row[1]),str(row[2]),str(row[3]),str(row[4]),str(row[5])]))
        result.append(dic)
    print(result)
    return result
    
def userhome(request):
    ID_Num=request.session['user_id']
    print(ID_Num)
    sql="select * from p_h where ID_Num=\'"+ID_Num+"\'"
    print(sql)
    cursor=connection.cursor()
    cursor.execute(sql)
    rows=his_fetchall(cursor)
    return render(request,'userhome.html',{"rows":rows})