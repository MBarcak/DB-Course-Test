# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Airline(models.Model):
    airline_num = models.CharField(primary_key=True, max_length=6)
    dep = models.CharField(max_length=10)
    dest = models.CharField(max_length=10)
    dep_time = models.TimeField()
    dest_time = models.TimeField()

    class Meta:
        managed = False
        db_table = 'airline'


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class Flight(models.Model):
    f_id = models.CharField(db_column='F_ID', primary_key=True, max_length=10)  # Field name made lowercase.
    dep_date = models.DateField()
    price1 = models.SmallIntegerField(blank=True, null=True)
    price2 = models.SmallIntegerField(blank=True, null=True)
    price3 = models.SmallIntegerField(blank=True, null=True)
    seat1 = models.SmallIntegerField(blank=True, null=True)
    seat2 = models.SmallIntegerField(blank=True, null=True)
    seat3 = models.SmallIntegerField(blank=True, null=True)
    company = models.CharField(max_length=35)
    p_type = models.CharField(max_length=6, blank=True, null=True)
    airline_num = models.ForeignKey(Airline, models.DO_NOTHING, db_column='airline_num')

    class Meta:
        managed = False
        db_table = 'flight'
        unique_together = (('f_id', 'dep_date'),)


class Passenger(models.Model):
    id_num = models.CharField(db_column='ID_Num', primary_key=True, max_length=18)  # Field name made lowercase.
    pname = models.CharField(db_column='PName', max_length=9)  # Field name made lowercase.
    age = models.SmallIntegerField()
    sex = models.CharField(max_length=1, blank=True, null=True)
    tele = models.CharField(unique=True, max_length=11)
    pd = models.CharField(max_length=40, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'passenger'


class QueryTable(models.Model):
    query_num = models.CharField(primary_key=True, max_length=8)
    id_num = models.ForeignKey(Passenger, models.DO_NOTHING, db_column='ID_Num',related_name='id_num_r')  # Field name made lowercase.
    f = models.ForeignKey(Flight, models.DO_NOTHING, db_column='F_ID',related_name='f_r', blank=True, null=True)  # Field name made lowercase.
    f_id_l = models.CharField(db_column='F_ID_l', max_length=10)  # Field name made lowercase.
    dep_date = models.ForeignKey(Flight, models.DO_NOTHING, db_column='dep_date',related_name='dep_date_r', blank=True, null=True)
    dep_date_l = models.DateField()
    query_date = models.DateField()
    dep_l = models.CharField(max_length=10)
    dest_l = models.CharField(max_length=10)

    class Meta:
        managed = False
        db_table = 'query_table'
