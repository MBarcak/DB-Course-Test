"""QFlight URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from flight import views as flight_views

urlpatterns = [
    url(r'^$', flight_views.index),
    url(r'index/$', flight_views.index),
    url(r'query/$', flight_views.query),
    url(r'query.html$', flight_views.get_query),
    url(r'login/', flight_views.login),
    url(r'register/', flight_views.register),
    url(r'^logout/', flight_views.logout),
    url(r'query_flight/$', flight_views.query_flight),
    url(r'index/includeVariables$', flight_views.login),
    url(r'userhome/$', flight_views.userhome),
    url(r'select/$', flight_views.select),
    path('admin/', admin.site.urls),
]