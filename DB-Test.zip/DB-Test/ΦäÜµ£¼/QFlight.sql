create database QFlight;
use Qflight;

create table passenger
(ID_Num char(18) primary key,
PName char(9) not null,
age smallint not null default(0),
sex char(1) CHECK(sex IN('男','女')),
tele char(11) not null unique,
pd char(20) not null,
check (age>0));

ALTER TABLE passenger ADD INDEX index_tele (tele);
ALTER TABLE passenger ADD INDEX index_pd (pd);

create table airline
(airline_num char(6) primary key,
dep char(10) not null,
dest char(10) not null,
dep_time time not null,
dest_time time not null,
check (dep<>dest));

create table flight
(F_ID char(10) not null,
dep_date date not null,
price1 smallint,price2 smallint,price3 smallint,
seat1 smallint,seat2 smallint, seat3 smallint,
company char(35) not null,
p_type char(6),
airline_num char(6) not null,
primary key(F_ID,dep_date),
foreign key(airline_num) references airline(airline_num),
FOREIGN KEY (airline_num) REFERENCES airline(airline_num) 
ON DELETE CASCADE ON UPDATE CASCADE,
check(price1>0),check(price2>0),check(price3>0),
check(seat1>0),check(seat2>0),check(seat3>0));

create table query_table
(ID_Num char(18) not null,
F_ID char(10),
F_ID_l char(10) not null,
dep_date date,
dep_date_l date not null,
query_date date not null,
dep_l char(10) not null,
dest_l char(10) not null,
primary key(ID_Num,F_ID,dep_date),
foreign key(ID_Num) references passenger(ID_Num),
foreign key(F_ID,dep_date) references flight(F_ID,dep_date),
FOREIGN KEY (ID_Num) REFERENCES passenger(ID_Num)
ON DELETE CASCADE ON UPDATE CASCADE
);

/*查询航班*/
create view query_flight1(F_ID,dep_date,dep,dest) as
select F_ID,dep_date,dep,dest from airline,flight where airline.airline_num=flight.airline_num;

/*查详细信息*/
create view query_flight2(F_ID,dep_date,dep,dest,dep_time,dest_time,price1,price2,price3,seat1,seat2,seat3,company,p_type) as
select F_ID,dep_date,dep,dest,dep_time,dest_time,price1,price2,price3,seat1,seat2,seat3,company,p_type from airline,flight where airline.airline_num=flight.airline_num;

/*登录*/
create view upload(tele,pd) as
select tele,pd from passenger;

/*查历史记录*/
create view p_h(ID_Num,query_date,F_ID_l,dp_date_l,dep_l,dest_l) as
select ID_Num,query_date,F_ID_l,dep_date_l,dep_l,dest_l from query_table;


/*
insert into flight(F_ID,dep_date,price1,price2,price3,seat1,seat2,seat3,company,p_type,airline_num)value
('CA110','2019-10-03',1580,980,750,9,3,8,'Air China','B747','BS101');
insert into airline(airline_num,dep,dest,dep_time,dest_time) value ('BS101','Beijing','Shanghai','15:30:00','17:45:00');
insert into flight(F_ID,dep_date,price1,price2,price3,seat1,seat2,seat3,company,p_type,airline_num)value
('MU3510','2019-10-04',1530,940,780,7,9,13,'China Eastern Airlines','A340','BS101');
*/
