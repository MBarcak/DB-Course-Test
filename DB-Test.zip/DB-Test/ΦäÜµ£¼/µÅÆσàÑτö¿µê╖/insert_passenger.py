#encoding:utf-8

import pymysql
import random
import hashlib
import time
import datetime
import string

def init_passenger():
    '''生成身份证号'''
    #地区号
    addr=str(random.randint(110100,659004))
    #生日
    start="1930-01-01"
    end="2009-12-30"
    days = (datetime.datetime.strptime(end,"%Y-%m-%d") - datetime.datetime.strptime(start,"%Y-%m-%d")).days + 1
    birthday = datetime.datetime.strptime(start,"%Y-%m-%d") + datetime.timedelta(random.randint(0,days))
    bir=datetime.datetime.strftime(birthday,"%Y%m%d")
    ex=str(random.randint(0000,9999))
    id_num=addr+bir+ex
    '''姓名'''
    a1=['赵', '钱', '孙', '李', '周', '吴', '郑', '王', '冯', '陈', '褚', '卫', '蒋', '沈', '韩', '杨', '朱', '秦', '尤', '许',
        '何', '吕', '施', '张', '孔', '曹', '严', '华', '金', '魏', '陶', '姜', '戚', '谢', '邹', '喻', '柏', '水', '窦', '章',
        '云', '苏', '潘', '葛', '奚', '范', '彭', '郎', '鲁', '韦', '昌', '马', '苗', '凤', '花', '方', '俞', '任', '袁', '柳',
        '酆', '鲍', '史', '唐', '费', '廉', '岑', '薛', '雷', '贺', '倪', '汤', '滕', '殷', '罗', '毕', '郝', '邬', '安', '常',
        '乐', '于', '时', '傅', '皮', '卞', '齐', '康', '伍', '余', '元', '卜', '顾', '孟', '平', '黄', '和', '穆', '萧', '尹',
        '姚', '邵', '堪', '汪', '祁', '毛', '禹', '狄', '米', '贝', '明', '臧', '计', '伏', '成', '戴', '谈', '宋', '茅', '庞',
        '熊', '纪', '舒', '屈', '项', '祝', '董', '梁']
    a2=['玉','明','龙','芳','军','玲','爱','国','孔', '曹', '严', '华', '金', '魏', '陶', '姜', '戚', '谢', '邹', '喻', '柏', '水', '窦', '章',
        '云', '苏', '潘', '葛', '奚', '范', '彭', '郎', '鲁', '韦', '昌', '马', '苗', '凤', '花', '方', '俞', '任', '袁', '柳',
        '酆', '鲍', '史', '唐', '费', '廉', '岑', '薛', '雷', '贺', '倪', '汤', '滕', '殷', '罗', '毕', '郝', '邬', '安', '常',
        '乐', '于', '时', '傅', '皮', '卞', '齐', '康', '伍', '余', '元', '卜', '顾', '孟', '平', '黄', '和', '穆', '萧']
    a3=['','立','玲','','国','','费', '廉', '岑', '薛', '雷', '贺', '倪', '汤', '滕', '殷', '','罗', '毕', '郝', '邬', '安', '常',
        '乐', '于', '时', '傅', '皮', '','卞', '齐', '康', '伍', '余', '', '元', '卜', '顾', '孟', '平', '黄', '和', '穆', '萧']
    name=random.choice(a1)+random.choice(a2)+random.choice(a3)
    '''年龄'''
    age=2019-int(id_num[6:10])
    '''性别'''
    s=['男','女']
    sex=random.choice(s)
    '''电话号'''
    num_start = ['134', '135', '136', '137', '138', '139', '150', '151', '152', '158', '159', '157', '182', '187', '188',
           '147', '130', '131', '132', '155', '156', '185', '186', '133', '153', '180', '189']
    tele=random.choice(num_start)+str(random.randint(10000000,99999999))
    '''密码'''
    pd=""
    nn=string.ascii_letters+string.digits
    for i in range(8):
        pd+=random.choice(nn)  
    sha=hashlib.sha1(pd.encode('utf-8'))
    pd1 = sha.hexdigest()
    re=[id_num,name,age,sex,tele,pd1]
    return re
    
def insert():
    db=pymysql.connect(host='127.0.0.1',port=3306,user='root',passwd='123456',db='qflight',charset='utf8')
    cursor=db.cursor()
    for i in range(9999):
        try:
            p=init_passenger()
            cursor.execute("insert passenger(ID_Num,PName,age,sex,tele,pd) value(%s,%s,%s,%s,%s,%s)",(p[0],p[1],str(p[2]),p[3],p[4],p[5]))
            print(i)
            db.commit()
        except:
            db.rollback()
    cursor.close()
    db.close()
    
    
insert()