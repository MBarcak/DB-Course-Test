
import pymysql
import random
import datetime
import threading
import json
import time

airline=[]
fid=[]
date=[['2019-12-10','2019-12-12','2019-12-14','2019-12-16','2019-12-18','2019-12-20','2019-12-22','2019-12-24'],
      ['2019-12-11','2019-12-13','2019-12-15','2019-12-17','2019-12-19','2019-12-21','2019-12-23','2019-12-25'],
      ['2019-12-11','2019-12-14','2019-12-17','2019-12-20','2019-12-23','2019-12-26'],
      ['2019-12-10','2019-12-14','2019-12-18','2019-12-22','2019-12-26'],
      ['2019-12-10','2019-12-15','2019-12-20','2019-12-25'],
      ['2019-12-12','2019-12-18','2019-12-24']]
air=[['CA','中国国际航空'],['CZ','中国南方航空'],['MU','中国东方航空'],['HU','海南航空'],['ZH','深圳航空'],
     ['MF','厦门航空'],['KN','中国联合航空'],['JD','首都航空'],['FM','上海航空'],]
ptype=['B747','B777','B787','A340','A310','A380','B737','B738','A320','A300']

def init_time():
    tuple_t1=(1976,1,1,0,0,0,0,0,0)              #设置开始日期时间元组（1976-01-01 00：00：00）
    tuple_t2=(1990,12,31,23,59,59,0,0,0)
    ts_t1 = time.mktime(tuple_t1)
    ts_t2 = time.mktime(tuple_t2)
    t = random.randint(ts_t1, ts_t2)
    tuple_t = time.localtime(t)
    str_t = time.strftime("%H:%M:%S", tuple_t)
    dt_t = datetime.datetime.strptime(str_t, "%H:%M:%S")
    return str_t


def init_airline():
    city=['北京','北京','北京','北京','北京','北京','北京','天津','上海','上海','上海','上海','上海','上海','广州','广州','广州','广州',
          '广州','广州','广州','广州','深圳','深圳','深圳','深圳','深圳','深圳','深圳','深圳','厦门','武汉','南京','重庆','成都','昆明',
          '西安','杭州','大连','青岛','郑州','哈尔滨','长沙','桂林','厦门','厦门','厦门','厦门','厦门','厦门','香港','香港','香港','天津',
          '太原','南宁','香港','澳门','兰州','银川','南昌','三亚','福州','长春','沈阳','呼和浩特','拉萨','乌鲁木齐','西宁','济南','台北']
    dep=random.choice(city)
    while True:
        dest=random.choice(city)
        if dest!=dep:
            break
        else:
            continue

    dep_time=init_time()
    while True:
        dest_time=init_time()
        dep_list=dep_time.split(':')
        dest_list=dest_time.split(':')

        if (int(dep_list[0])>=23) and int(dest_list[0])<=2:
            break
        elif (int(dep_list[0])<23) and (int(dep_list[0])+1<=int(dest_list[0])):
            if abs(int(dest_list[0])-int(dep_list[0]))*60+int(dest_list[1])-int(dep_list[1])<=60:
                continue
            elif abs(int(dest_list[0])-int(dep_list[0]))*60+abs(int(dest_list[1])-int(dep_list[1]))>480:
                continue
            else:
                break
    re=[dep,dest,dep_time,dest_time]
    return re

def init_flight():
    global fid
    global date
    global air
    global ptype
    airline_num=str(random.choice(airline))
    air_choice=random.choice(air)
    while True:
        F_ID=air_choice[0]+str(random.randint(1000,9999))
        if F_ID not in fid:
            company=air_choice[1]
            break
        else:
            continue
    p_type=random.choice(ptype)
    date_choice=random.choice(date)
    for i in date_choice:
        dep_date=i
        price1=str(random.randint(1800,3200))
        price2=str(random.randint(1000,1800))
        price3=str(random.randint(400,1000))
        seat1=str(random.randint(0,28))
        seat2=str(random.randint(0,35))
        seat3=str(random.randint(0,45))
        re=[F_ID,dep_date,price1,price2,price3,seat1,seat2,seat3,company,p_type,airline_num]
        insert_flight(re)
        

def insert_air():
    global airline
    num=1001
    db=pymysql.connect(host='127.0.0.1',port=3306,user='root',passwd='123456',db='QFlight',charset='utf8')
    cursor=db.cursor()
    for i in range(400):
        try:
            a=init_airline()
            cursor.execute("insert airline(airline_num,dep,dest,dep_time,dest_time) value(%s,%s,%s,%s,%s)",(str(num),a[0],a[1],a[2],a[3]))
            db.commit()
            airline.append(num)
        except:
            db.rollback()
        num+=1

def insert_flight(f):
    global fid
    db=pymysql.connect(host='127.0.0.1',port=3306,user='root',passwd='123456',db='QFlight',charset='utf8')
    cursor=db.cursor()
    try:
        cursor.execute("insert flight(F_ID,dep_date,price1,price2,price3,seat1,seat2,seat3,company,p_type,airline_num) value(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(f[0],f[1],f[2],f[3],f[4],f[5],f[6],f[7],f[8],f[9],f[10]))
        db.commit()
        fid.append(f[0])
    except:
        db.rollback()


insert_air()
for i in range(820):
    init_flight()